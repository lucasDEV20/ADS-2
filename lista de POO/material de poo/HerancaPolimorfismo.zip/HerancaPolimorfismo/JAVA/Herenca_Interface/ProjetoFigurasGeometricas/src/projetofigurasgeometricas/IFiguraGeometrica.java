/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetofigurasgeometricas;

/**
 *
 * @author ejmcc
 */
public interface IFiguraGeometrica {
    float areaTotal(); // Metodo Abstrato - sem codigo
    float volume();// Metodo Abstrato - sem codigo
    String tipoFigura();// Metodo Abstrato - sem codigo
}
